<?php
include('connection.php');
class login extends connection
{
	
	
	function getUserSessionName()
	{
		return 'adminId';
	}
	function getUserSessionId()
	{
		return $_SESSION['adminId'];
	}
	
	function getAdminName()
	{
		return $_SESSION['adminFullName'];
	}	
	
}
$classLogin = new login();
/**********************************************end login class  *********************/


/********************************************** insert and update class  *********************/
class save_data extends connection
{
	function secureSuperGlobal($var)                           // secure special characters /                  
	{
		$var	= htmlspecialchars(stripslashes($var));
		$var	= str_ireplace("script", "blocked", $var);
		$var	= ($var);
		return $var;
	}
	function insert($tbl,$fields,$static_fields,$data,$where)               // insert the query
	{
		foreach($fields as $key=>$field)
		{
			$bits[] = "`$field` = '".$this->secureSuperGlobal($data[$field])."'";
		}
		$setStr=implode(",",$bits);	
			  $query="insert into $tbl set ".$setStr.$static_fields;

		return $this->aLastId($query);
	}
	function update($tbl,$fields,$static_fields,$data,$where)               // insert the query
	{
		foreach($fields as $key=>$field)
		{
			$bits[] = "`$field` = '".$this->secureSuperGlobal($data[$field])."'";
		}
		$setStr=implode(",",$bits);	
		   $query="update $tbl set $setStr $static_fields where $where";
	 return $this->aRunQuery($query);
	}
	function run_query($query)               // insert the query
	{
		
		return $this->aRunQuery($query);
	}
	
		function save_record($query)               // insert the query
	{
		
		return $this->aLastId($query);
	}
	
	
	function fetch_rows($query)               // insert the query
	{
		
		return $this->aAllRow($query);
	}

	function execute_assoc_query($query)               // insert the query
	{
		
		return $this->aAllRow_Assoc($query);
	}     
}
$classSave = new save_data();
/**********************************************insert and update  *********************/


/************************************************************************* Country State ******************/

class fetch extends connection
{
	
	function select_Records($table)
	{
	 	$query ="SELECT * FROM $table";
		return $this->aAllRow($query);
	}
	
	function execute_query($query)
	{
	 
		return $this->aAllRow($query);
	}
		function run_query($query)
	{
	 
		return $this->aRunQuery($query);
	}
	
	
	function select_Record_Where($table,$where)
	{
		 $query ="SELECT * FROM $table $where";
		return $this->aAllRow($query);
	}
	

}
$classFetch = new fetch();


/*********************************for fetch the record from databaes*************************************************************************/
class fetch_selected_row extends connection
{
	
	function get_selected_Records($table,$id,$value)
	{
	  	$query ="SELECT * FROM $table where $id='$value'";
		return $this->aAllRow($query);
	}

	function get_selected_Records_limit($table,$id,$value)
	{
	 	$query ="SELECT * FROM $table where $id='$value' limit 0,1";
		return $this->aAllRow($query);
	}
	function get_max_vochor_where($table,$col_name,$where)
	{
	       $query ="SELECT max($col_name) as $col_name FROM $table $where";
		return $this->aSinRow($query);
	}
	
	function get_max_vochor($table,$col_name)
	{
	     $query ="SELECT max($col_name) as $col_name FROM $table ";
		return $this->aSinRow($query);
	}
	
   function get_selected_Column($table,$id,$value,$col_name)
	{
	      $query ="SELECT $col_name FROM $table where $id='".$value."' ";
		return $this->aSinRow($query);
	}
	function get_selected_Column1($table,$id,$value,$col_name)
	{
	       $query ="SELECT $col_name FROM $table where $id='".$value."' ";
		return $this->aSinRow($query);
	}
	function count_rows($table,$id,$value,$col_name)
	{
	     $query ="SELECT $col_name FROM $table where $id='".$value."' ";
		return $this->aNumRow($query);
	}
	function count_rows_where($table,$where)
	{
	     $query ="SELECT * FROM $table  $where ";
		return $this->aNumRow($query);
	}
	
 function get_selected_where($table,$where)
	{
	    $query ="SELECT * FROM $table $where";
		return $this->aAllRow($query);
	}
	function get_selected_where1($table,$where)
	{
	      $query ="SELECT * FROM $table $where";
		return $this->aAllRow($query);
	}
	function get_selected_where_query($query)
	{
	    
		return $this->aAllRow($query);
	}
	
	
function get_total_rows_where($table,$where,$id)
	{
		   $query ="SELECT max($id) as maxid FROM $table $where";
		return $this->aSinRow($query);
	}
}
$classFetch_Selected_Row = new fetch_selected_row();

class get_session extends connection
{
		
	function get_active_session()
	{
		$query ="select ses_id from tbl_session where status= '1'";
		$value =  $this->aSinRow($query);
		return $value['ses_id'];
	}
	
}
$active_session = new get_session();
/**********************************************************************************************************/





?>
