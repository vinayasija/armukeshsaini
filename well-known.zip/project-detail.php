<?php  include('includes/header.php');
	$query = "select * from tbl_product where pro_id = '".$_GET['pro_id']."' ";
	$rest  =$classSave->fetch_rows($query);
	foreach($rest as $row){
		extract($row);
		$update=1;
	}
	$cats = $classFetch_Selected_Row->get_selected_Column('tbl_category','cat_id',$cat_id,'cat_name');

?>
        <div class="page-content bg-white" id="lightgallery">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Project Detail</h1>
						<!-- Breadcrumb row -->
						<nav aria-label="breadcrumb" class="breadcrumb-row">
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="las fa-home mr-2"></i>Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Project Detail</li>
							</ul>
						</nav>
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			
			
			<!-- Our Gallery END -->
			<!-- Project Info -->
			<section class="section-full content-inner">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 m-b30">
							<div class="row widget widget_getintuch widget_getintuch-pro-details m-lr0">
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-lr0">
									<div class="pro-details">
										<i class="ti ti-user"></i>
										<strong>CLIENT</strong> <?php echo ucwords($pro_client); ?>
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-lr0">
									<div class="pro-details">
										<i class="ti ti-user"></i>
										<strong>ARCHITECT</strong> Mukesh Saini
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-lr0">
									<div class="pro-details">
										<i class="ti ti-location-pin"></i>
										<strong>LOCATION</strong><?php echo ucwords($pro_address); ?>
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-lr0">
									<div class="pro-details">
										<i class="ti ti-ruler-alt-2"></i>
										<strong>SIZE</strong><?php echo ucwords($pro_size); ?>
									</div>
								</div>
								<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-lr0">
									<div class="pro-details">
										<i class="ti ti-home"></i>
										<strong>TYPE</strong><?php echo $cats['cat_name']; ?> Project
									</div>
								</div>
							</div>
							
						
						</div>
						<div class="col-lg-7">
							<div  class="m-b30 wow fadeIn mfp-gallery" data-wow-duration="2s" data-wow-delay="0.2s">
								<div class="dlab-box gallery-box-2">
									<div class="dlab-media dlab-img-overlay1 dlab-img-effect"> 
										<a href="javascript:void(0);"> <img src="adminpanel/uploads/<?php echo $file; ?>" alt=""> </a>
										<div class="overlay-bx">
											<span data-exthumbimage="adminpanel/uploads/<?php echo $file; ?>" data-src="adminpanel/uploads/<?php echo $file; ?>"  title="<?php echo $pro_client; ?>"> </span>
										</div>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<!-- blog grid END -->
			</section>
			<!-- contact area END -->
		</div>
		<?php  include('includes/footer.php')  ?>