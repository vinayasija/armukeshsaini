<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Privacy Policy</h1>
						<!-- Breadcrumb row -->
						<nav aria-label="breadcrumb" class="breadcrumb-row">
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="las fa-home mr-2"></i>Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
							</ul>
						</nav>
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			<!-- Main Slider -->
			<section class="content-inner-2">				
				<div class="container">
					<div class="row">
						<div class="col-lg-8 col-md-7 col-sm-12">
							<div class="dlab-page-text sidebar">
								<h3 class="title">The Industrial Privacy Policy was updated on 25 June 2018.</h3>
								<p class="font-18">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,<a href="javascript:void(0);"> Contact Us </a>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
								<div class="dlab-divider bg-gray-dark"></div>
								<h3 class="title">Who We Are and What This Policy Covers</h3>
								<p class="font-18">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
								<div class="dlab-divider bg-gray-dark"></div>
								<h3 class="title">What personal information we collect</h3>
								<ul class="list-circle primary m-a0">
									<li>The Industrial Privacy Policy was updated on 25 June 2018. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's </li>
									<li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
									<li>Remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</li>
									<li>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
									<li>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
								</ul>
							</div>
						</div>
						<div class="col-lg-4 col-md-5 col-sm-12">
							<aside class="sticky-top">
								<div class="list-group mb-5">
									<a class="list-group-item" href="index.php"><i class="fa fa-home mr-2"></i>Home</a>
									<a class="list-group-item" href="about-us-1.php"><i class="fa fa-user mr-2"></i>About Us</a>
									<a class="list-group-item active" href="privacy-policy.php"><i class="fa fa-lock mr-2"></i>Privacy Policy</a>
									<a class="list-group-item" href="blog-grid.php"><i class="fa fa-rss mr-2"></i>Blog</a>
									<a class="list-group-item" href="contact-us-1.php"><i class="fa fa-phone mr-2"></i>Contact Us</a>
								</div>
								<ul class="contact-question">
									<li>
										<i class="fa fa-map-marker"></i>
										<h4 class="title">Address</h4>
										<p>123 West Street, Melbourne Victoria 3000 Australia</p>
									</li>
									<li>
										<i class="fa fa-envelope-o"></i>
										<h4 class="title">Email</h4>
										<p>0001architect@gmai.com</p>
									</li>
									<li>
										<i class="fa fa-phone"></i>
										<h4 class="title">Phone</h4>
										<p>+61 3 8376 6284<br>+23 123 456 7890</p>
									</li>
									<li>
										<i class="fa fa-fax"></i>
										<h4 class="title">Fax</h4>
										<p>+000 123 2294 089</p>
									</li>
								</ul>
							</aside>
						</div>
					</div>
				</div>
			</section>
			<div>				
				<img src="images/bg-view.png" class="bg-view" alt=""/>
			</div>
		</div>
		<?php include('includes/footer.php') ?>