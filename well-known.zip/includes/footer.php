  <!-- Footer -->
  <footer class="site-footer" id="footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
					<div class="col-md-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.3s">
                        <div class="widget widget_about">
							<div class="footer-logo">
								<a href="index.php"><img src="images/logo1.png" alt=""/></a> 
							</div>
							
							<div class="dlab-social-icon">
								<ul>
								<?php 
								if($info_facebook !=''){
								?>
									<li><a class="fa fa-facebook" target="_blank"  href="<?php echo $info_facebook; ?>"></a></li>
								<?php } ?>
									<?php 
								if($info_twitter !=''){
								?>
									<li><a class="fa fa-twitter" target="_blank" href="<?php echo $info_twitter; ?>"></a></li>
								<?php } ?>
								
									<?php 
								if($info_linkdin !=''){
								?>
									<li><a class="fa fa-linkedin" target="_blank" href="<?php echo $info_linkdin; ?>"></a></li>
								<?php } ?>
								
								
								</ul>
							</div>
						</div>
                    </div>
					<div class="col-md-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.6s">
						<div class="widget">
							<h5 class="footer-title">Contact Us</h5>
							<ul class="contact-info-bx">
								<li><i class="las la-map-marker"></i><strong>Address</strong> <?php echo $info_address; ?></li>
								<li><i class="las la-phone-volume"></i><strong>Call :-</strong>     <?php echo $info_phone; ?></li>
								<li><i class="las la-phone-volume"></i><strong>Call :-</strong>     <?php echo $info_alt_phone; ?></li>
							
							</ul>
						</div>
                    </div>
				
                </div>
            </div>
        </div>
        <!-- footer bottom part -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12 text-md-left text-center"> <span> © Vinay Asija 9416509833</span> </div>
                    <div class="col-md-6 col-sm-12 text-md-right text-center"> 
						<div class="widget-link "> 
							<ul>
								<li><a href="about-the-architect.php"> About</a></li>
								<li><a href="contact.php"> Contact Us</a></li>
							
							</ul>
						</div>
					</div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer END-->
    </div>

<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6150286ed326717cb6835d00/1fgghrsbd';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->



<!-- JAVASCRIPT FILES ========================================= -->
<script src="js/jquery.min.js"></script><!-- JQUERY.MIN JS -->
<script src="vendor/wow/wow.js"></script><!-- WOW JS -->
<script src="vendor/bootstrap/js/popper.min.js"></script><!-- POPPER.MIN JS -->
<script src="vendor/bootstrap/js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script src="vendor/owl-carousel/owl.carousel.js"></script><!-- OWL-CAROUSEL JS -->
<script src="vendor/magnific-popup/magnific-popup.js"></script><!-- MAGNIFIC-POPUP JS -->
<script src="vendor/counter/waypoints-min.js"></script><!-- WAYPOINTS JS -->
<script src="vendor/counter/counterup.min.js"></script><!-- COUNTERUP JS -->
<script src="vendor/imagesloaded/imagesloaded.js"></script><!-- IMAGESLOADED -->
<script src="vendor/masonry/masonry-3.1.4.js"></script><!-- MASONRY -->
<script src="vendor/masonry/masonry.filter.js"></script><!-- MASONRY -->
<script src="vendor/lightgallery/js/lightgallery-all.min.js"></script><!-- LIGHTGALLERY -->
<script src="vendor/bootstrap-select/bootstrap-select.min.js"></script><!-- BOOTSTRAP SELECT -->
<script src="js/dz.carousel.js"></script><!-- OWL-CAROUSEL -->
<script src="js/custom.js"></script><!-- CUSTOM JS -->

<!-- REVOLUTION JS FILES -->
<script src="vendor/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="vendor/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>
<!-- Slider revolution 5.0 Extensions  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="vendor/revolution/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="js/rev.slider.js"></script>

<script>

jQuery(document).ready(function() {
	'use strict';
	dz_rev_slider_1();
});	/*ready*/
</script>
<script>
jQuery(document).ready(function() {
	'use strict';
	dz_rev_slider_3();
});	/*ready*/
</script>

<script>

$(document).ready(function() {
  var galleryTop = $("#galleryTop");
  var galleryBottom = $("#galleryBottom");
  var slidesPerPage = 4; //globaly define number of elements per page
  var syncedSecondary = true;

	  galleryTop.owlCarousel({
		items : 2,
		autoplaySpeed: 3000,
		navSpeed: 3000,
		paginationSpeed: 3000,
		slideSpeed: 3000,
		smartSpeed: 3000,
        autoplay: 3000,
		nav: false,
		center:true,
		autoWidth:true,
		dots: false,
		loop: true,
		responsiveRefreshRate : 200,
		responsive:{
			0:{
				items : 1,
				autoWidth:false,
				stagePadding:30
			},
			767:{
				autoWidth:false
			},
			1200:{
				items : 2
			}
		}	
	  })
	  
	  .on('changed.owl.carousel', syncPosition);

	  galleryBottom.on('initialized.owl.carousel', function () {
		  galleryBottom.find(".owl-item").eq(0).addClass("current");
		}).owlCarousel({
		items : slidesPerPage,
		dots: false,
		nav: false,
		margin:20,
		autoplaySpeed: 3000,
		navSpeed: 3000,
		paginationSpeed: 3000,
		slideSpeed: 3000,
		smartSpeed: 3000,
        autoplay: 3000,
		stagePadding:100,
		slideBy: slidesPerPage, //alternatively you can slide by 1, this way the active slide will stick to the first item in the second carousel
		responsiveRefreshRate : 50,
		navText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
		responsive:{
			0:{
				items:2,
				stagePadding:30,
				margin:15
			},
			480:{
				items:2
			},			
			768:{
				items:3
			},
			1024:{
				items:4
			},
			1400:{
				items:5
			}
		}
	  }).on('changed.owl.carousel', syncPosition2);

  function syncPosition(el) {
    //if you set loop to false, you have to restore this next line
    //var current = el.item.index;
    
    //if you disable loop you have to comment this block
    var count = el.item.count-1;
    var current = Math.round(el.item.index - (el.item.count/2) - .5);
    
    if(current < 0) {
      current = count;
    }
    if(current > count) {
      current = 0;
    }
    
    //end block

    galleryBottom
      .find(".owl-item")
      .removeClass("current")
      .eq(current)
      .addClass("current");
    var onscreen = galleryBottom.find('.owl-item.active').length - 1;
    var start = galleryBottom.find('.owl-item.active').first().index();
    var end = galleryBottom.find('.owl-item.active').last().index();
    
    if (current > end) {
      galleryBottom.data('owl.carousel').to(current, 100, true);
    }
    if (current < start) {
      galleryBottom.data('owl.carousel').to(current - onscreen, 100, true);
    }
  }
  
  function syncPosition2(el) {
    if(syncedSecondary) {
      var number = el.item.index;
      galleryTop.data('owl.carousel').to(number, 100, true);
    }
  }
  
  galleryBottom.on("click", ".owl-item", function(e){
		e.preventDefault();
		var number = $(this).index();
		//galleryTop.data('owl.carousel').to(number, 300, true);
		
		galleryTop.data('owl.carousel').to(number, 300, true);
		
	});
});
</script>
</body>

</html>