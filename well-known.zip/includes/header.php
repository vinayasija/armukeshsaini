<?php include('common/class.php');
 	$query = "select * from tbl_info where info_id = '1' ";
	$rest  =$classSave->fetch_rows($query);
	foreach($rest as $row){
		extract($row);
		$update=1;
	}
	$query = "select * from tbl_about where about_id = '1' ";
	$rest  =$classSave->fetch_rows($query);
	foreach($rest as $row){
		extract($row);
		$update=1;
	}
	?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ARCHITECTURE & INTERIORS</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.min.css">
    <link rel="stylesheet" href="vendor/bootstrap-select/bootstrap-select.min.css">
    <link rel="stylesheet" href="vendor/lightgallery/css/lightgallery.min.css">
    <link rel="stylesheet" href="vendor/animate/animate.css">
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    
	<!-- REVOLUTION SLIDER CSS
	<link rel="stylesheet" type="text/css" href="vendor/revolution/revolution/css/revolution.min.css">  -->
</head>

<body>

	<div class="onepage"></div>
    <div class="page-wraper">
		<!-- header -->
		<header class="site-header header-transparent">
			<div class="top-bar">
				<div class="container-fluid">
					<div class="row d-flex justify-content-between align-items-center">
						<div class="dlab-topbar-left">
						     
						 
							<ul>
                			        
							    	<li><i class="la la-user"></i> <?php echo $info_owner; ?></li>
								<li><i class="la la-phone-volume"></i> <?php echo $info_phone; ?></li>
								<li><i class="las la-map-marker"></i> <?php echo $info_address; ?></li>
							</ul>
						</div>
						<div class="dlab-topbar-right">
							<ul>
								<li><i class="la la-clock"></i>  Mon - Sat 10.00 - 20.00</li>
								<li><i class="las la-envelope-open"></i> <?php echo $info_email; ?></li>
							</ul>
					
                 
						</div>
					</div>
				</div>
			</div>
			<!-- main header -->
			<div class="sticky-header main-bar-wraper navbar-expand-lg">
				<div class="main-bar clearfix ">
					<div class="container-fluid clearfix">
					<!-- website logo -->
					<div class="logo-header mostion logo-dark">
						<a href="index.php"><img src="images/logo1.png" alt=""  style="height: 88px;" ></a>
					</div>
					<!-- nav toggle button -->
					<button class="navbar-toggler collapsed navicon justify-content-end " type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span></span>
						<span></span>
						<span></span>
					</button>
					<!-- extra nav -->
					
					<div class="header-nav navbar-collapse collapse justify-content-end" id="navbarNavDropdown">
						<div class="logo-header d-md-block d-lg-none">
							<a href="index.php"><img src="images/logo1.png" alt=""></a>
						</div>
						<ul class="nav navbar-nav navbar">	
							<li class="active" ><a href="index.php">Home</i></a>
								
							</li>
							<li class="active" ><a href="services.php">Services</i></a>
								
							</li>
							
							<li><a href="portfolio.php">Portfolio</i></a>
							
							</li>
							<li class="active"><a href="about-the-architect.php">About Us</a>
							
							</li>
								<li class="active"><a href="our-team.php">Our Team</a>
							
							</li>
							<li><a href="contact.php">Contact Us</i></a>
							
							</li>
						</ul>
						<div class="dlab-social-icon">
							<ul>
								<li><a class="site-button circle fa fa-facebook" href="javascript:void(0);"></a></li>
								<li><a class="site-button  circle fa fa-twitter" href="javascript:void(0);"></a></li>
								<li><a class="site-button circle fa fa-linkedin" href="javascript:void(0);"></a></li>
								<li><a class="site-button circle fa fa-instagram" href="javascript:void(0);"></a></li>
							</ul>
						</div>		
					</div>
				</div>
				</div>
			</div>
			<!-- main header END -->
		</header>
		<!-- header END -->