<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Company History</h1>
						<!-- Breadcrumb row -->
						<nav aria-label="breadcrumb" class="breadcrumb-row">
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="las fa-home mr-2"></i>Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Company History</li>
							</ul>
						</nav>
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			<!-- Main Slider -->
			<section class="content-inner-2" data-content="PORTFOLIO">				
				<div class="container">
					<div class="section-head text-center">
						<p>VIEW PORTFOLLO</p>
						<h2 class="title m-b10">Our Best Projects</h2>
					</div>
					<div class="row">
						<div class="col-lg-12 text-center">
							<div class="site-filters filter-style1 clearfix m-b20">
								<ul class="filters" data-toggle="buttons">
									<li data-filter="" class="btn active"><input type="radio"><a href="#"><span>All</span></a></li>
								<?php 
								$query = "select * from tbl_category where cat_status = '1' ";
                            	$rest  =$classSave->fetch_rows($query);
                            	foreach($rest as $row){
                            		extract($row);
                            		$cats_value =str_replace(" ","_",$cat_name);;
                            		
                            	?>
                            	<li data-filter="<?php echo strtolower($cats_value); ?>" class="btn"><input type="radio"><a href="#"><span><?php echo ucwords($cat_name); ?></span></a></li>
                            	<?php 
                            	}
								?>
									
									
								
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="clearfix" id="lightgallery">
					<ul id="masonry" class="gallery mfp-gallery text-center portfolio-bx p-l0">
						
						
					    	<?php 
								$query = "select * from tbl_category where cat_status = '1' ";
                            	$rest  =$classSave->fetch_rows($query);
                            	foreach($rest as $row){
                            		
                            		$cats_value =str_replace(" ","_",$row['cat_name']);;
                            		
                            	 
								$query2 = "select * from tbl_product where pro_status = '1' and cat_id = '".$row['cat_id']."' ";
                            	$rest2  =$classSave->fetch_rows($query2);
                            	foreach($rest2 as $row2){
                            		extract($row2);
                            		
                            		
                            	?>	
						
						<li data-category="<?php echo strtolower($cats_value); ?>" class="card-container col-lg-3 col-md-4 col-sm-6 p-lr0 <?php echo strtolower($cats_value); ?> wow fadeIn" data-wow-duration="2s" data-wow-delay="0.2s">
							
									
							
							<div class="dlab-media dlab-img-overlay1 dlab-img-effect portbox1">
								<img src="adminpanel/uploads/<?php echo $file; ?>" alt=""/>
								<div class="overlay-bx">
									<div class="portinner">
										<span><?php echo $pro_client; ?></span>
										<h3 class="port-title"><a href="project-detail.php?pro_id=<?php echo $pro_id; ?>"><?php echo $pro_address; ?></a></h3>
										<a href="project-detail.php?pro_id=<?php echo $pro_id; ?>" class="btn btn-primary m-t15">View Project</a>
									</div>
								</div>
							</div>
							
							
							
							
						</li>
					<?php 
                        }
                            	}
                    ?>        	
					
					</ul>
				</div>
			</section>
		</div>
		<?php include('includes/footer.php') ?>