<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Error 404</h1>
						<!-- Breadcrumb row -->
						<nav aria-label="breadcrumb" class="breadcrumb-row">
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="las fa-home mr-2"></i>Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Error 404</li>
							</ul>
						</nav>
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			<!-- Main Slider -->
			<section class="content-inner-1" data-content="ERROR 404">				
				<div class="container">
					<div class="error-page text-center">
						<div class="dz_error">404</div>
						<h2 class="error-head">The Link You Folowed Probably Broken, or the page has been removed...</h2>
						<div class="m-b30">
							<div class="subscribe-form p-a0">
								<form>
									<div class="input-group">
										<input name="text" class="form-control radius-no bg-black" placeholder="Type and hit Enter..." type="text">
										<span class="input-group-btn">
											<button type="submit" class="btn radius-no white"><img src="images/icons/search-icon.png" alt=""></button>
										</span> 
									</div>
								</form>
							</div>
						</div>
						<a href="index.php" class="btn btn-primary btn-lg">Return to Home</a>
					</div>
				</div>
			</section>
		</div>
		<?php include('includes/footer.php') ?>