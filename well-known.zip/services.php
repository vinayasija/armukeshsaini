<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Services</h1>
						<!-- Breadcrumb row -->
					
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			<!-- About Us -->
            <section class="content-inner">
                <div class="container">
					<div class="row">
						
						
					 <?php
				$count=1;
				$query  = " select * from tbl_services where ser_status='1'";
				$result = $classSave->fetch_rows($query);
				foreach($result as $row){
					extract($row);
					if($team_status == '1'){
						$s=0;$color='success';$value = "check";
					}if($team_status == '0'){
						$s=1;$color='danger'; $value = "ban";
					}
					
					
				?>		
						<div class="col-lg-4 col-md-6 col-sm-6 m-b30">
							<div class="icon-bx-wraper about-bx">
									<img src='adminpanel/uploads/<?php echo $file; ?>' />
								<div class="icon-content">
									<h5 class="dlab-tilte"><?php echo $ser_name; ?></h5>
									<p><?php echo $ser_desc; ?></p>
								</div>
							</div>
						</div>
					<?php 
				}
				?>
					</div>
                </div>
            </section>
		
	
		</div>
		<?php include('includes/footer.php') ?>