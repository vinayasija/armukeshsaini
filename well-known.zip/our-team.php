<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>Our Team</h1>
						<!-- Breadcrumb row -->
					
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
		
		
		
			<section class="content-inner-2" data-content="OUR TEAM">
				<div class="container">
					<div class="section-head text-center">
						<p>Meet The Team</p>
						<h2 class="title">Our Team</h2>
					</div>
					<div class="row">
						
						 <?php
            				$count=1;
            				$query  = " select * from tbl_team";
            				$result = $classSave->fetch_rows($query);
            				foreach($result as $row){
            					extract($row);
            					if($team_status == '1'){
            						$s=0;$color='success';$value = "check";
            					}if($team_status == '0'){
            						$s=1;$color='danger'; $value = "ban";
            					}
            					
            					
            				?>	
						
						<div class="col-lg-3 col-md-6 col-sm-6 m-md-b30 wow fadeIn" data-wow-duration="2s" data-wow-delay="0.2s">
							<div class="our-team team-style1">
								<div class="dlab-media radius-sm">
									<img src="adminpanel/uploads/<?php echo $file; ?>" alt="<?php echo $team_name; ?>" style='height:280px;'>
								</div>
								<div class="team-title-bx text-center">
									<h2 class="team-title"><?php echo $team_name; ?></h2>
									<span class="clearfix"><?php echo $team_qualifications; ?></span>
									<span class="clearfix"><?php echo $team_exp; ?></span>
								</div>
							</div>
						</div>
						<?php 
            				}
            			?>
						
					
						
					</div>
				</div>
			</section>
			<!-- Our Team END -->
			<!-- Our Partners -->
	
			<!-- Our Partners END -->
		</div>
		<?php include('includes/footer.php') ?>