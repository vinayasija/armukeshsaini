<?php include('includes/header.php') ?>
        <div class="sidenav-list">
			<ul class="navbar">
				<li><a class="scroll nav-link" href="#home"><i class="las la-home"></i> <span>Home</span></a></li>
				<li><a class="scroll nav-link" href="#specifications"><i class="las la-file-alt"></i> <span>specifications</span></a></li>
				<li><a class="scroll nav-link" href="#aboutUs"><i class="las la-user"></i> <span>ABOUT US</span></a></li>
				
				
				<li><a class="scroll nav-link" href="#ourServices"><i class="las la-cog"></i> <span>Our Services</span></a></li>
			
				<li><a class="scroll nav-link" href="#footer"><i class="las la-phone-volume"></i> <span>Contact Us</span></a></li>
			</ul>
		</div>
		<div class="page-content">
		    <div id="home" class="carousel slide" data-ride="carousel" >

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <?php 
    $hel=1;
    $query = "select * from tbl_slider";
	$rest  =$classSave->fetch_rows($query);
	foreach($rest as $row){
    ?>
    
    <li data-target="#demo" data-slide-to="<?php echo $hel; ?>" <?php if($hel=='1') { ?> class="active" <?php  } ?> ></li>
    <?php 
	} 
	$hel++;?>
    
  
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    
    <?php 
    $hello=1;
    $query = "select * from tbl_slider";
	$rest  =$classSave->fetch_rows($query);
	foreach($rest as $row){
    ?>
    <div class="carousel-item <?php if($hello=='1') { ?>active <?php } ?>">
      <img src="images/main-slider/slider1.png" alt="Los Angeles" width="100%" height="500">
    </div>
    <?php 
    $hello++;
	}
	?>
   
    
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
		<?php  $query = "select * from tbl_about";
                                	$rest  =$classSave->fetch_rows($query);
                                	foreach($rest as $row){
                                	    $about_title = $row['about_title'];
                                	    $about_desc = $row['about_desc'];
                                	    
                                	}
							?>
			
			<section class="content-inner about-box" data-content="ABOUT US" id="aboutUs">	
				<div class="about-bg"></div>
				<div class="container">
					<div class="row">
						<div class="col-md-7 col-lg-6">
							<div class="section-head">
								<h2 class="title wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.2s">Projects Overview</h2>
								<div class="dlab-separator bg-primary  wow fadeInUp" data-wow-duration="4s" data-wow-delay="0.2s"></div>
								<h4 class="mb-4 wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.6s"><?php echo $about_title; ?></h4>
							
							
								<p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.8s" style='text-align:justify;'>
								   <?php echo substr($about_desc,0,510); ?> ...
								   
								   
								   </p>
								
							</div>
							<a href="about-the-architect.php" class="btn btn-primary wow fadeInUp" data-wow-duration="2s" data-wow-delay="1.2s">About Us</a>
						</div>
						<div class="col-md-5 col-lg-6"></div>
					</div>
				</div>
			</section>
			
			
			<section class="content-inner-2" data-content="OUR SERVICES" id="ourServices">				
				<div class="container">
					<div class="row align-items-end section-head wow fadeInUp" data-wow-duration="2s" data-wow-delay="0.5s">
						<div class="col-md-6">
							<h2 class="title">Our Projects</h2>
							<div class="dlab-separator bg-primary"></div>
							
						</div>
						<div class="col-md-6 text-md-right">
							<a href="portfolio.php" class="btn btn-primary">View Portfolio</a>
						</div>
					</div>
				</div>
				<div class="service-area" style="background-image:url(images/gallery/main1.jpg); ">
					<div class="row spno service-row">
				
				<?php
					$query = "select * from tbl_product where file !='' ORDER BY RAND() LIMIT 10 ";
	                $rest  =$classSave->fetch_rows($query);
	                foreach($rest as $row){
	                    extract($row);
				?>
					
					
						<div class="col wow bounceInUp" data-wow-duration="2s" data-wow-delay="0.2s">
							<div class="service-box">
								<div class="media">
									<img src="adminpanel/uploads/<?php echo $file; ?>" alt="<?php echo $pro_client; ?>"/>
								</div>
								<div class="info">
									<h4 class="title"><?php echo $pro_client; ?></h4>
									<p><?php echo $pro_address; ?></p>
								</div>
							</div>
						</div>
					<?php 
	                }?>
					
						
					</div>
				</div>
			</section>
	
		
		</div>
	     <?php include('includes/footer.php') ?>