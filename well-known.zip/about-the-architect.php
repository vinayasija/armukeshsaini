<?php include('includes/header.php') ?>
        <div class="page-content bg-white">
			<!-- Main Slider -->
			<div class="dlab-bnr-inr">
				<div class="container">
					<div class="dlab-bnr-inr-entry">
						<h1>About us</h1>
						<!-- Breadcrumb row -->
						<nav aria-label="breadcrumb" class="breadcrumb-row">
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="#"><i class="las fa-home mr-2"></i>Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">About Us</li>
							</ul>
						</nav>
						<!-- Breadcrumb row END -->
					</div>
				</div>
			</div>
			<!-- Main Slider -->
			<section class="content-inner-1" data-content="ABOUT US">				
				<div class="container">
					<div class="section-head text-center">
						<h2 class="title"><?php echo $about_title; ?></h2>
						<p><?php echo $about_desc; ?>
						</p>
					</div>
					<div class="row">
						<div class="col-md-4 col-lg-2 col-6 mb-4">
							<div class="aminite-icon-bx">
								<i class="flaticon-drama"></i>
								<h4 class="title">Activity Room</h4>
							</div>
						</div>
						<div class="col-md-4 col-lg-2 col-6 mb-4 mt-lg-3 mt-0">
							<div class="aminite-icon-bx">
								<i class="flaticon-cinema"></i>
								<h4 class="title">mini Theater</h4>
							</div>
						</div>
						<div class="col-md-4 col-lg-2 col-6 mb-4 mt-lg-5 mt-0">
							<div class="aminite-icon-bx">
								<i class="flaticon-stationary-bike"></i>
								<h4 class="title">Fitnesh Gym </h4>
							</div>
						</div>
						<div class="col-md-4 col-lg-2 col-6 mb-4 mt-lg-5 mt-0">
							<div class="aminite-icon-bx">
								<i class="flaticon-round-table"></i>
								<h4 class="title">Multipurpose Hall</h4>
							</div>
						</div>
						<div class="col-md-4 col-lg-2 col-6 mb-4 mt-lg-3 mt-0">
							<div class="aminite-icon-bx">
								<i class="flaticon-gamepad"></i>
								<h4 class="title">Games Room</h4>
							</div>
						</div>
						<div class="col-md-4 col-lg-2 col-6 mb-4">
							<div class="aminite-icon-bx">
								<i class="flaticon-reading-book"></i>
								<h4 class="title">library</h4>
							</div>
						</div>
					</div>
				</div>
			</section>
			<div class="map-view" style='display:none;'>
				<div class="row spno">
					<div class="col-md-6"><img src="images/map1.jpg" alt=""/></div>
					<div class="col-md-6"><img src="images/sitemap.jpg" alt=""/></div>
				</div>
			</div>
			
			<section style='display:none;'>				
				<div class="aminite-overlay parallax" style="background-image:url(images/amenities/bg/pic1.jpg)">
					<div class="aminite-over-area">
						<div class="overlay-box">
							<h2 class="title">Dive in To The Aquamarine waters of our swanky Swimming pool</h2>
							
						</div>
					</div>
				</div>
				<div class="aminite-overlay" style="background-image:url(images/amenities/bg/pic2.jpg)">
					<div class="aminite-over-area">
						<div class="overlay-box">
							<h2 class="title">Temple</h2>
							
						</div>
					</div>
				</div>
				<div class="aminite-overlay" style="background-image:url(images/amenities/bg/pic3.jpg)">
					<div class="aminite-over-area">
						<div class="overlay-box">
							<h2 class="title">Squash Court</h2>
							
						</div>
					</div>
				</div>
			</section>
		
		</div>
   <?php include('includes/footer.php') ?>